# chinesesilklanterns.github.io

Cursed Boardgame Interactive NSFWCYOA
Created by /u/chinesesilklanterns
May 2020

I hope you enjoyed playing this as much as I did making it. 
If you want to contact me, find me on Reddit (https://reddit.com/u/chinesesilklanterns)
If you've found content that you think I might enjoy, do share it with me!

License: You are free to use and redistribute this game, associated code and files entirely free of charge in a non-commercial setting, so long as proper attribution is given to me. 
I do not own the copyright to the illustrated images in the 'icons' folder used in this game, they belong to various artists found online.
You agree not to hold me responsible for any damages that may result from your use of these files, use at your own risk.
You may create derivative works, using all or parts of the files provided here, as long as the abovementioned acknowledgement is retained.

Basically, if you share or modify this, be nice and credit me.